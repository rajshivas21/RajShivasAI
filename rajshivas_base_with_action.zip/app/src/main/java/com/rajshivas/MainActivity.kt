package com.rajshivas

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var shivasSwitch: Switch
    private lateinit var greetButton: Button
    private lateinit var guideButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)
        shivasSwitch = findViewById(R.id.switch_shivas)
        greetButton = findViewById(R.id.btn_greet)
        guideButton = findViewById(R.id.btn_guide)

        greetButton.setOnClickListener {
            speak("Namaste Mukesh. RajShivas AI is ready. How can I help you today?")
        }

        guideButton.setOnClickListener {
            startActivity(Intent(this, AIGuideActivity::class.java))
        }

        // Request microphone permission if needed
        val micPermission = android.Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val request = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                if (!granted) {
                    Toast.makeText(this, "Microphone permission recommended for voice features", Toast.LENGTH_LONG).show()
                }
            }
            request.launch(micPermission)
        }

        shivasSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                Toast.makeText(this, "Shivas Mode enabled", Toast.LENGTH_SHORT).show()
                // placeholder: enable background listening or custom behaviour
            } else {
                Toast.makeText(this, "Shivas Mode disabled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val res = tts.setLanguage(Locale("en", "IN"))
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                // fallback
                tts.language = Locale.US
            }
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rajshivas_greet")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
    }
}
